<!DOCTYPE html>
<html lang="id">
<head>
   <meta charset="UTF-8">
   <title>Project Data Karyawan</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="css/mycss.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Poem</h2>
                </div>
                <div class="pull-right mb-2">
                    
                    <a class="btn btn-success" href="<?php echo e(url('/poetry/data/create')); ?>"> Create Data Poem</a>  
                </div>
            </div>
        </div>
        <?php if($message = Session::get( 'success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <tr>
                <th>Id</th>
                <th>Title</th>
                <th>Piece</th>
                <th>Author</th>
                <th>Image</th>
                <th width="280px">Action</th>
            </tr>
            
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e($item->piece); ?></td>
                <td><?php echo e($item->author); ?></td>
                <td><img src="/images/<?php echo e($item->image); ?>" width="100px"></td>
                <td>
                    
                    <form action="<?php echo e(url("/poetry/$item->id")); ?>" method="Post">
                    
                    <a class="btn btn-primary" href="<?php echo e(url("/poetry/$item->id/edit")); ?>" onclick="myHello()">Edit</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field( 'DELETE' ); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                      </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </body>
      <script src="js/myjs.js"></script>
</html>


<?php /**PATH /Users/nabilaateya/poem-project/resources/views/poetries/index.blade.php ENDPATH**/ ?>